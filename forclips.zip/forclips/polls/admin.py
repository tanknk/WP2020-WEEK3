from django.contrib import admin

from polls.models import Poll, Question, Choice
from django.contrib.auth.models import Permission
# Register your models here.
admin.site.register(Poll)

admin.site.register(Question)

admin.site.register(Choice)

admin.site.register(Permission)