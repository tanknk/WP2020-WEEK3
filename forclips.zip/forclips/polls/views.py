import json

from django.contrib.auth import authenticate, login, logout
from django.db.models import Count
from django.forms import formset_factory
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from polls.models import Answer, Poll, Question
from django.contrib.auth.decorators import login_required, permission_required  

# Create your views here.
def my_login(request):
    context = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('index')
        else:
            context['error'] = 'Wrong username or password'
        

    return render(request, template_name='login.html', context=context)


def my_logout(request):
    logout(request)
    return redirect('login')

def change_password(request):
    context = {}
    if request.method == 'POST':
        user = User.objects.get(username=request.user)
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        # check that the passwords match
        if password1 == password2:
            user.set_password(password1)
            user.save()
            return redirect('login')
        else:

            context['error'] = 'Password not match.'

        # reset password 

    return render(request, template_name='change_password.html', context=context)


def index(request):
    search = request.GET.get('search', '')

    poll_list = Poll.objects.filter(
        del_flag=False, title__icontains=search
    ).annotate(question_count=Count('question')) # COUNT(*) GROUP BY

    context = {
        'poll_list': poll_list,
        'search': search
    }

    return render(request, template_name='polls/index.html', context=context)

@login_required
@permission_required('polls.view_poll')
def detail(request, poll_id):
    poll = Poll.objects.get(pk=poll_id)

    return render(request, 'polls/detail.html', { 'poll': poll })

@login_required
@permission_required('polls.add_poll')
def create(request):
    if request.method == 'POST' and request.FILES['picture']:
        title = request.POST.get('title')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        picture =  request.FILES['picture']
        polls = Poll(title=title, start_date=start_date, end_date=end_date, picture=picture)
        polls.save()
        return redirect('index')
    return render(request, 'polls/create.html')
