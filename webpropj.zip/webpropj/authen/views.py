from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, Permission
from django.core.exceptions import ObjectDoesNotExist
from post.models import Post
# from django.contrib.auth.decorators import login_required, permission_required


def my_login(request):

    if request.user.is_authenticated: # ป้องกันผู้ใช้ที่ล็อกอินอยู่แล้ว ยิงเข้าหน้า Login ตรง ๆ
        return redirect('index')
    
    context = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            next_url = request.POST.get('next_url')
            if next_url:
                print('not enter')
                return redirect(next_url)
            else:
                print('enter')
                return redirect('index')
        else:
            context['error'] = 'Wrong username or password.'

    next_url = request.GET.get('next')

    if next_url:
        context['next_url'] = next_url

    return render(request, "authen/login.html", context=context)


def my_logout(request):
    logout(request)
    return redirect('index')


def my_signup(request):
    
    if request.user.is_authenticated: # ป้องกันผู้ใช้ที่ล็อกอินอยู่แล้ว ยิงเข้าหน้า Register ตรง ๆ
        return redirect('index')

    context = {}
    check_regis = True
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')

        # The any() method returns True if any element of an iterable is True. If not, any() returns False.
        # if not เช็คว่าเป็น False มั้ย

        # Username Validation
        # เช็คว่ามีตัวอักษรใน username มั้ย
        if not any(char.islower() | char.isupper() for char in username):
            check_regis = False
            context['username'] = "Your username must contain at least one characters."

        # เช็คว่ามี Username นี้อยู่ในระบบมั้ย (ถ้าไม่ทำตรงส่วนนี้ จะเกิดหน้า Error เลยหลีกเลี่ยงไว้)
        try:
            if User.objects.get(username=username) != None:
                check_regis = False
                context['username'] = "Your username was taken."
                return render(request, "authen/signup.html", context=context)
        except ObjectDoesNotExist:
            pass

        # Password Validation
        # เช็คความยาวของ Password
        if len(password) < 8:
            check_regis = False
            context['password'] = "Your password format doesn't right."
        # เช็คว่ามีตัวเลขอยู่ใน password มั้ย
        if not any(char.isdigit() for char in password):
            check_regis = False
            context['password'] = "Your password format doesn't right."
        # เช็คว่ามีตัวอักษรพิมพ์ใหญ่อยู่ใน password มั้ย
        if not any(char.isupper() for char in password):
            check_regis = False
            context['password'] = "Your password format doesn't right."
        # เช็คว่ามีตัวอักษรพิมพ์เล็กอยู่ใน password มั้ย
        if not any(char.islower() for char in password):
            check_regis = False
            context['password'] = "Your password format doesn't right."
        # เช็คว่า Password และ Password confirmation ตรงกันมั้ย
        if password != password2:
            check_regis = False
            context['password2'] = "Your password & password confirmation doesn't match."

        # Email Validation
        # หาว่ามี . ในอีเมลมั้ย ถ้าเจอจะ return index ถ้าไม่เจอจะ return -1
        if email.find('.') == -1 or len(email) > 254:
            check_regis = False
            context['email'] = "Your email format doesn't right."

        # First name and Last name validation
        if not any(char.islower() | char.isupper() for char in first_name):
            check_regis = False
            context['first_name'] = "Your first name must contain at least one characters."
        if not any(char.islower() | char.isupper() for char in last_name):
            check_regis = False
            context['last_name'] = "Your last name must contain at least one characters."
        if any(char.isdigit() for char in first_name):
            check_regis = False
            context['first_name'] = "Your first name format doesn't right."
        if any(char.isdigit() for char in last_name):
            check_regis = False
            context['last_name'] = "Your last name format doesn't right."
        if len(first_name) > 50:
            check_regis = False
            context['first_name'] = "First name must less than 50 characters"
        if len(last_name) > 50:
            check_regis = False
            context['last_name'] = "Last name must less than 50 characters"

        if check_regis:
            user = User(username=username, password=password, first_name=first_name,
                        last_name=last_name, email=email, is_staff=False, is_superuser=False)
            user.set_password(password)
            user.save()
            login(request, user)
            return redirect('index')

    return render(request, "authen/signup.html", context=context)
