from django.shortcuts import render, redirect
from post.models import Post, Message
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    search_txt_sell = request.GET.get("sellSearch")
    search_txt_buy = request.GET.get("buySearch")

    if(search_txt_sell is not None and search_txt_buy is None): #กรณีที่ค้นหา ช่องขาย อย่างเดียว
        sell = Post.objects.filter(text_book__icontains=search_txt_sell).filter(type='S').filter(status="OPEN")
        buy = Post.objects.filter(type='B').filter(status="OPEN")
    elif(search_txt_sell is None and search_txt_buy is not None): #กรณีที่ค้นหา ช่องซื้อ อย่างเดียว
        sell = Post.objects.filter(type='S').filter(status="OPEN")
        buy = Post.objects.filter(text_book__icontains=search_txt_buy).filter(type='B').filter(status="OPEN")
    else: #กรณีไม่ค้นหาเลย
        sell = Post.objects.filter(type='S').filter(status="OPEN")
        buy = Post.objects.filter(type='B').filter(status="OPEN")
    
    context = {
        "sell" : sell,
        "buy" : buy
    }
    return render(request, "post/index.html", context=context)

@login_required
def post_list(request):
    search_txt_myPost = request.GET.get("myPost")
    
    if(search_txt_myPost is None):
        post = Post.objects.filter(create_by__username=request.user)
    else:
        post = Post.objects.filter(create_by__username=request.user).filter(text_book__icontains=search_txt_myPost)
    
    context = {
        "post" : post
    }
    return render(request, 'post/post_list.html', context=context)

@login_required
def create_post(request):
    context = {}
    check_book = True

    if request.method == "POST" and request.FILES['picture']:
        text_book = request.POST.get('text_book')
        type = request.POST.get('type')
        price = request.POST.get('price')
        picture = request.FILES['picture']

        # Book Validator
        # เช็คว่าผู้ใช้ได้กรอกชื่อหนังสือมั้ย (ไม่ใช่ ' ' หรือ ตัวเลข หรือ เครื่องหมายพิเศษ)
        if not any(char.isalpha() for char in text_book):
            check_book = False
            context['text_book'] = "Your text book must contain at least one characters."
        
        # เช็คว่าผู้ใช้ได้เลือกชนิดของโพสต์มั้ย
        if type == "default":
            check_book = False
            context['type'] = "Please select your post type."

        if check_book:
            post = Post(text_book=text_book, type=type, price=price, picture=picture, status="OPEN")
            post.create_by_id = request.user.pk
            post.save()
            return redirect('post_list')
            
    return render(request, 'post/create_post.html', context=context)

def view_post(request, post_id):
    post = Post.objects.get(pk=post_id)

    if post.status == "CLOSE" and post.create_by != request.user: # ป้องกันคนยิงเข้าโพสต์ที่ปิดไปแล้ว โดยจะเช็คสถานะของโพสต์และชื่อผู้ใช้งานว่าตรงกับผู้สร้างโพสต์มั้ย
        return redirect('index')
    
    comments = Message.objects.filter(post_id_id=post.id)
    context = {
        'post' : post
    }
    
    if request.method == "POST":
        new_comment = request.POST.get('comment')
        if not any(char.isalpha() for char in new_comment):
            context['error'] = 'Your comment must contain at least 1 character.'
        else:
            comment = Message(message=new_comment, create_by_id=request.user.pk, post_id_id=post_id)
            comment.save()  
            return redirect('view_post', post_id=post_id)

    if comments:
        context['post'] = post
        context['comment'] = comments

    return render(request, 'post/view_post.html', context=context)

@login_required
def close_post(request, post_id):
    post = Post.objects.get(pk=post_id)

    if post.create_by != request.user: # ป้องกันผู้ใช้คนอื่นยิงปิดโพสต์คนอื่นตรง ๆ
        return redirect('index')

    post.status = "CLOSE"
    post.save()
    return redirect('post_list')