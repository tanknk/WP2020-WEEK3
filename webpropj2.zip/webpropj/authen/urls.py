from django.urls import path, include
from . import views

urlpatterns = [
    path('login/', views.my_login, name='login'),
    path('logout/', views.my_logout, name='logout'),
    path('signup/', views.my_signup, name='signup'),
    path('', include('post.urls'), name='index'),
]